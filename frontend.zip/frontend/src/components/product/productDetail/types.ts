export interface IProductDetailProps {
    productDetail: {
        id: string,
        name: string,
        description: string,
        price: number,
        options?: Array<
            {
                name: string,
                variants: Array<
                    {
                        name: string,
                        extra_price?: number
                    }
                >
            }>
        ,
        discounts?: Array<
            {
                membership_only: boolean,
                percent?: number,
                amount?: number
            }
        >
    }
}

export interface IVariantsObj {
    [key: string]: string;
  }
