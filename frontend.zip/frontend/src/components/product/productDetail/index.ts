import ProductDetails from './productDetail';
export default ProductDetails;
