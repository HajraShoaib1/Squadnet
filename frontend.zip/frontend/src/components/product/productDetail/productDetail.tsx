import { useQuery } from '@apollo/client';
import { FC } from 'react';
import { useParams, useSearchParams } from 'react-router-dom';
import { GET_PRODUCT } from './query';
import './styles.css';

const ProductDetails: FC<any> = ({ productDetail }) => {

  const [queryParams] = useSearchParams()
  const params = useParams()

  const { data } = useQuery(GET_PRODUCT, {
    variables: {
      id: Number(params.slug)
    },
    context: {
      headers: {
        Authorization: queryParams.get('is_member')
      }
    }
  });

  const handleAddToCart = () => {
    localStorage.clear()
    localStorage.setItem("product", data?.product)
  }

  return (
    <div className='productDetail'>
      <h4>{data?.product.name}</h4>
      <h4>${data?.product.price}</h4>
      {data?.product?.options &&
        data?.product?.options?.map((option: any) => (
          <>
            <h6>{option.name}</h6>
            <select
              name={option.name}
              style={{ width: '100px', height: '40px' }}
            >
              {option.variants.map((variant: any) => (
                <option value={variant.name}>{variant.name}</option>
              ))}
            </select>
          </>
        ))}
      <button className='addToCartButton' onClick={handleAddToCart}>Add to Cart</button>
    </div>
  );
};
export default ProductDetails;
