import { gql } from "@apollo/client";

export const GET_PRODUCT = gql`
    query product($id: Int!) {
      product(id: $id) {
        id
        name
        description
        price
        options {
          name
          variants {
              name
              extra_price
          }
        }
        discounts {
          id
          amount
          percent
        }
      }
    }
`