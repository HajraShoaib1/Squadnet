import { productImage } from './constants';
import './styles.css';

/** component to display product image*/
const ProductImage = () => {
	return (
		<div className='imageContainer'>
			<img src={productImage} alt='Girl in a jacket' width='400' height='450' />
		</div>
	);
};
export default ProductImage;
