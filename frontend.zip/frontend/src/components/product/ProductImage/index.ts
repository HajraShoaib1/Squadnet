import ProductImage from './productImage';
export default ProductImage;
