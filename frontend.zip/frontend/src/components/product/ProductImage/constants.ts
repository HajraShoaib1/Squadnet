export const productImage: Readonly<string> =
  'https://5.imimg.com/data5/CR/OL/NO/ANDROID-36904487/img-20181220-wa0001-jpg-500x500.jpg'
  ;
