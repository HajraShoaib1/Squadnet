import ProductDetails from '../../components/product/productDetail';
import ProductImage from '../../components/product/ProductImage';
import './styles.css';

const ProductDetailsPage = () => {
	return (
		<div className='mainContainer'>
			<h4>
				<u>1.Squadent VIP Demo App</u>
				2.Tshirt
			</h4>
			<div className='productContainer'>
				<ProductImage />
				<ProductDetails productDetail={{}} />
			</div>
		</div>
	);
};

export default ProductDetailsPage;
