import prisma from "./client"

async function main() {

  //Add product data
  await prisma.product.deleteMany({})
  await prisma.product.createMany({
    data: [
      {
        id: 1,
        name: "Dance Class",
        description: "Junior class for age 9 - 12",
        price: 200,
      },
      {
        id: 2,
        name: "T-shirt",
        description: "Blacktown FC t-shirt",
        price: 25,
      },
      {
        id: 3,
        name: "Ball",
        description: "Merchandised",
        price: 40,
      }
    ] 
  })

  //Add options data
  await prisma.option.deleteMany({})
  await prisma.option.createMany({
    data: [
      {
        id: 1,
        name: "Level",
        productId: 1
      },
      {
        id: 2,
        name: "Size",
        productId: 2
      },
      {
        id: 3,
        name: "Colors",
        productId: 2
      }
    ]
  })

  //Add variants data
  await prisma.variant.deleteMany({})
  await prisma.variant.createMany({
    data: [{
      id: 1,
      name: "Basic",
      optionId: 1
    },
    {
      id: 2,
      name: "Intermediate",
      extraPrice: 20,
      optionId: 1
    },
    {
      id: 3,
      name: "Advanced",
      extraPrice: 40,
      optionId: 1
    },
    {
      id: 4,
      name: "S",
      optionId: 2
    },
    {
      id: 5,
      name: "M",
      optionId: 2
    },
    {
      id: 6,
      name: "L",
      optionId: 2
    },
    {
      id: 7,
      name: "Black",
      optionId: 3
    },
    {
      id: 8,
      name: "Red",
      optionId: 3
    }
  ]
  })

  //Add Discount data 
  await prisma.discount.deleteMany({})
  await prisma.discount.createMany({
    data: [
      {
        id: 1,
        membershipOnly: false,
        percent: 5,
        productId: 1
      },
      {
        id: 2,
        membershipOnly: true,
        amount: 30,
        productId: 1
      },
    ]
  })

}

main()
  .catch((e) => {
    console.error(e)
    process.exit(1)
  })
  .finally(async () => {
    await prisma.$disconnect()
  })