import prisma from "../../prisma/client";

const resolvers = {
    Query: {
      product: async (parent: any, args: any, ctx: any) => {
        const product = await prisma.product.findUnique({
          where: {
            id: args.id
          }
        })
        return product
      }
    },
    Product: {
      options: async (product: any) => {
        return await prisma.option.findMany({
          where: { productId: product.id }
        })
      },
      discounts: async (product: any) => {
        return await prisma.discount.findMany({
          where: { productId: product.id }
        })
      }
    },
    Option: {
      variants: async (option: any) => {
        return await prisma.variant.findMany({
          where: { optionId: option.id }
        })
      }
    },
  };

  export default resolvers;