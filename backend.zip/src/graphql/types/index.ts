import { gql } from "apollo-server-express";

const typeDefs = gql`
  type Product {
  id: Int!
  name: String
  created_at: String
  description: String
  price: Float
  options: [Option]
  discounts: [Discount]
}

type Option {
  id: Int!
  name: String
  product_id: Int!
  variants: [Variant]
}

type Variant {
  id: Int!
  name: String
  extra_price: Float
  option_id: Int!
}

type Discount {
  id: Int!
  amount: Float
  percent: Int
  product_id: Int!
}

type Query{
  product(id: Int!): Product
}


`;

export default typeDefs;