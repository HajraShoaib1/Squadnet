import { createServer } from "http";
import express from "express";
import { ApolloServer, AuthenticationError } from "apollo-server-express";
import typeDefs from "./graphql/types";
import resolvers from "./graphql/resolvers";

const startServer = async () => {
  const app = express();
  const httpServer = createServer(app);

  const apolloServer = new ApolloServer({ typeDefs, resolvers, context: ({req}) => {
    if(!req.headers.authorization){
      throw new AuthenticationError('user not logged in');
    }
  }})

  await apolloServer.start()

  apolloServer.applyMiddleware({ app, path: `/api` })

  httpServer.listen({ port: process.env.PORT || 4000 }, () =>
    console.log(`Server listening on localhost:4000${apolloServer.graphqlPath}`)
  )
}

startServer()