# GraphQL TypeScript Ecommerce Demo App

## Initial set up

```shell
git clone <REPO_NAME>
```

Once you have your own repository set up, install the local package dependencies:

```shell
npm install
```

You can now run your server locally and open up the playground:

```shell
npm run dev
```

## Local database set up

```shell
docker-compose up -d
```

If you're using the Docker extension in VSCode, you can use this instead of running the previous command in the terminal.

Anytime you make changes to the `prisma.schema` file, you'll need to run migrations so the changes are applied to your local database.

There is a script you can use for this:

```shell
npm run migrate
npm run seed
```

